


<?php $__env->startSection('navbar-content'); ?>



<div class="justify-center items-center p-4 md:flex ">
    <div class="p-4">
        <h1 class="text-2xl font-semibold mb-4">Modifier un client</h1>
        <form action="<?php echo e(route('client.update', $client->id)); ?>" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div>
                <label for="nom" class="block font-medium">Nom</label>
                <input type="text" name="nom" id="nom" value="<?php echo e($client->nom); ?>" class="w-full border rounded p-2" required>
            </div>

            <div>
                <label for="adresse" class="block font-medium">Adresse</label>
                <input type="text" name="adresse" id="adresse" value="<?php echo e($client->adresse); ?>" class="w-full border rounded p-2" required>
            </div>

            <div>
                <label for="telephone" class="block font-medium">Téléphone</label>
                <input type="tel" name="telephone" id="telephone" value="<?php echo e($client->telephone); ?>" class="w-full border rounded p-2" required>
            </div>

            <div>
                <label for="email" class="block font-medium">Email</label>
                <input type="email" name="email" id="email" value="<?php echo e($client->email); ?>" class="w-full border rounded p-2" required>
            </div>

            <div>
                <label for="status" class="block font-medium">Status</label>
                <select name="status" id="statusClientCreate" class="w-full border rounded p-2" required>
                    <option value="Payé" class="text-green-500" <?php echo e($client->status === 'Payé' ? 'selected' : ''); ?>>Payé</option>
                    <option value="En attente de paiement" class="text-orange-500" <?php echo e($client->status === 'En attente de paiement' ? 'selected' : ''); ?>>En attente de paiement</option>
                    <option value="Non Payé" class="text-red-500" <?php echo e($client->status === 'Non Payé' ? 'selected' : ''); ?>>Non Payé</option>
                    <option value="En période de teste" class="text-gray-200" <?php echo e($client->status === 'En période de teste' ? 'selected' : ''); ?>>En période de teste</option>
                </select>
            </div>


            <div>
                <label for="prix" class="block font-medium">Prix</label>
                <input type="number" name="prix" value="<?php echo e($client->prix); ?>" class="w-full border rounded p-2" min="400" required>
            </div>

            <div>
                <label for="abonnement" class="block font-medium">Abonnement</label>
                <select name="abonnement" id="abonnement" class="w-full border rounded p-2" required>
                    <option value="Mensuel" <?php echo e($client->abonnement === 'Mensuel' ? 'selected' : ''); ?>>Mensuel</option>
                    <option value="Trimestriel" <?php echo e($client->abonnement === 'Trimestriel' ? 'selected' : ''); ?>>Trimestriel</option>
                    <option value="Semestriel" <?php echo e($client->abonnement === 'Semestriel' ? 'selected' : ''); ?>>Semestriel</option>
                    <option value="Annuel" <?php echo e($client->abonnement === 'Annuel' ? 'selected' : ''); ?>>Annuel</option>
                </select>
            </div>

            <div>
                <label for="paiement" class="block font-medium">Paiement :</label>
                <select id="paiement" name="paiement" class="w-full border rounded p-2" required>
                    <option value="Virement" <?php echo e($client->paiement === 'Virement' ? 'selected' : ''); ?>>Virement</option>
                    <option value="Espèces" <?php echo e($client->paiement === 'Espèces' ? 'selected' : ''); ?>>Espèces</option>
                </select>
            </div>
            <button name="edit" value="editandfacture" type="submit" class="w-full bg-green-500 text-white p-2 rounded hover:bg-green-600 focus:outline-none focus:ring focus:border-green-300">Mettre à jour et envoyer la facture</button>

            <?php if(Auth::check() && Auth::user()->role === 'Admin'): ?>
            <div>
                <label for="equipe" class="block font-medium">Equipe :</label>
                <select name="equipe_id" id="equipe" class="w-full border rounded p-2" value="<?php echo e($currentEquipe); ?>">
                    <?php $__currentLoopData = $equipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($equipe->id); ?>" <?php if($equipe->id == $currentEquipe): ?> selected <?php endif; ?>><?php echo e($equipe->nom); ?> (<?php echo e(count($equipe->utilisateurs)); ?> collaborateurs)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button name="edit" value="edit" type="submit" class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600 focus:outline-none focus:ring focus:border-blue-300">Mettre à jour</button> <br><br>
            <?php endif; ?>
            <br>

        </form>
    </div>
    <br>
    <div class=" p-4 md:pl-8">
        <?php if(Auth::check() && Auth::user()->role === 'Admin'): ?>
        <form action="<?php echo e(route('client.destroy', $client->id)); ?>" method="POST" class="w-full">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="w-full bg-red-500 text-white p-2 rounded mb-2 hover:bg-red-600 focus:outline-none focus:ring focus:border-blue-300">Supprimer</button>
        </form>
        <div>
            <label for="equipe" class="block font-medium">Equipe :</label>
            <select name="equipe" id="equipe" class="w-full border rounded p-2" value="<?php echo e($currentEquipe); ?>">
                <?php $__currentLoopData = $equipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($equipe->id); ?>" <?php if($equipe->id == $currentEquipe): ?> selected <?php endif; ?>><?php echo e($equipe->nom); ?> (<?php echo e(count($equipe->utilisateurs)); ?> collaborateurs)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php endif; ?>
    </div>

    <div class=" mx-auto p-6">
        <div>
            <label for="prix" class="block font-medium">Simulation de prix</label>
            <input type="number" id="prixClientShow" class="w-full border rounded p-2" required>
        </div><br>
        <table class="w-full border rounded-lg overflow-hidden">
            <thead>
                <tr class="bg-gray-100">
                    <th class="border p-8 font-medium text-gray-600">Durée</th>
                    <th class="border p-8 font-medium text-gray-600">Prix Normal</th>
                    <th class="border p-8 font-medium text-gray-600">Prix avec réduction</th>
                </tr>
            </thead>
            <tbody>
                <tr class="bg-white">
                    <td class="border p-4">1 mois</td>
                    <td class="border p-4 text-red-400" id="prixMensuel">0 DH</td>
                    <td class="border p-4 text-green-600" id="prixMensuelReduc">0 DH</td>
                </tr>
                <tr class="bg-gray-50">
                    <td class="border p-4">3 mois</td>
                    <td class="border p-4 text-red-400" id="prixTrimestriel">0 DH</td>
                    <td class="border p-4 text-green-600" id="prixTrimestrielReduc">0 DH</td>
                </tr>
                <tr class="bg-white">
                    <td class="border p-4">6 mois</td>
                    <td class="border p-4 text-red-400" id="prixSemestriel">0 DH</td>
                    <td class="border p-4 text-green-600" id="prixSemestrielReduc">0 DH</td>
                </tr>
                <tr class="bg-gray-50">
                    <td class="border p-4">12 mois</td>
                    <td class="border p-4 text-red-400" id="prixAnnuel">0 DH</td>
                    <td class="border p-4 text-green-600" id="prixAnnuelReduc">0 DH</td>
                </tr>
            </tbody>
        </table>
    </div>

</div>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Dent\resources\views/client/modifier.blade.php ENDPATH**/ ?>