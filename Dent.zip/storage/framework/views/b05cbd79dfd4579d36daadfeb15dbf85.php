

<?php $__env->startSection('navbar-content'); ?>

<div class="max-w-lg w-100 mx-auto p-4">
    <h1 class="text-2xl font-semibold mb-4">Créer un nouveau collaborateur</h1>
    <form action="<?php echo e(route('user.store')); ?>" method="POST" class="space-y-4">
        <?php echo csrf_field(); ?>
        <div>
            <label for="nom" class="block font-medium">Nom :</label>
            <input type="text" id="nom" name="nom" class="w-full border rounded p-2">
        </div>
        <div>
            <label for="prenom" class="block font-medium">Prenom :</label>
            <input type="text" id="prenom" name="prenom" class="w-full border rounded p-2">
        </div>
        <div>
            <label for="telephone" class="block font-medium">Téléphone :</label>
            <input type="text" id="telephone" name="telephone" class="w-full border rounded p-2">
        </div>
        <div>
            <label for="cin" class="block font-medium">CIN :</label>
            <input type="text" id="cin" name="cin" class="w-full border rounded p-2">
        </div>
        <div>
            <label for="role" class="block font-medium">Rôle :</label>
            <select id="role" name="role" class="w-full border rounded p-2">
                <option value="Admin" class="text-red-500">Admin</option>
                <option value="Collaborateur" class="text-blue-500">Collaborateur</option>
            </select>
        </div>
        <div>
            <label for="status" class="block font-medium">Status :</label>
            <select id="status" name="status" class="w-full border rounded p-2">
                <option value="Nouveau" class="text-red-500">Nouveau</option>
                <option value="En période de teste" class="text-orange-500">En période de teste</option>
                <option value="En attente de paiement" class="text-green-500">Confirmé</option>
            </select>
        </div>
        <div>
            <label for="email" class="block font-medium">Email :</label>
            <input type="email" id="email" name="email" class="w-full border rounded p-2">
        </div>
        <div>
            <label for="password" class="block font-medium">Mot de passe : (123456789)</label>
            <input type="password" id="password" name="password" class="w-full border rounded p-2" value="123456789" disabled>
        </div>
        <div>
            <label for="equipe" class="block font-medium">Equipe :</label>
            <select id="equipe" class="w-full border rounded p-2" name="equipe">
                <?php $__currentLoopData = $equipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($equipe->id); ?>"><?php echo e($equipe->nom); ?> (<?php echo e(count($equipe->utilisateurs)); ?> collaborateurs)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Créer le collaborateur</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Dent\resources\views/users/create.blade.php ENDPATH**/ ?>