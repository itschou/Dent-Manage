

<?php $__env->startSection('navbar-content'); ?>


<div class="overflow-x-auto">
    <div class="flex justify-between items-center py-2 px-4 mb-4">
        <h1 class="text-xl font-semibold">Historique de vente</h1>
    </div>
    
    <table id="historiqueTable" class="min-w-full border border-gray-300 text-center">
        <thead>
            <tr class="bg-gray-100">
                <th class="border p-2 text-center">Identifiant</th>
                <th class="border p-2 text-center">Date</th>
                <th class="border p-2 text-center">Equipe</th>
                <th class="border p-2 text-center">Collaborateur</th>
                <th class="border p-2 text-center">Client</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\DentAssist-Management\resources\views/historique/index.blade.php ENDPATH**/ ?>