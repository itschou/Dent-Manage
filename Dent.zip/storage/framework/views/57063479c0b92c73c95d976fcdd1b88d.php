

<?php $__env->startSection('navbar-content'); ?>

<div class="flex justify-center items-center pt-52">
    <div class="bg-white shadow-md rounded-lg p-8 w-full max-w-2xl mx-4">
        <form action="<?php echo e(route('hebergement.update', $hebergementget->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <table class="w-full mb-4">
                <tr>
                    <td class="px-2 py-1">Prix mensuel</td>
                    <td class="px-2 py-1">Prix trimestriel</td>
                    <td class="px-2 py-1">Prix semestriel</td>
                    <td class="px-2 py-1">Prix annuel</td>
                </tr>
                <tr>
                    <td class="px-2 py-1"><input type="text" class="w-full border p-1" name="prixMensuel" value="<?php echo e($hebergementget->prixMensuel); ?>"></td>
                    <td class="px-2 py-1"><input type="text" class="w-full border p-1" name="prixTrimestriel" value="<?php echo e($hebergementget->prixTrimestriel); ?>"></td>
                    <td class="px-2 py-1"><input type="text" class="w-full border p-1" name="prixSemestriel" value="<?php echo e($hebergementget->prixSemestriel); ?>"></td>
                    <td class="px-2 py-1"><input type="text" class="w-full border p-1" name="prixAnnuel" value="<?php echo e($hebergementget->prixAnnuel); ?>"></td>
                </tr>
            </table>
            <button class="bg-blue-500 text-white px-4 py-2 rounded-full hover:bg-blue-600 w-full">Mettre à jour</button>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Dent\resources\views/hebergement/index.blade.php ENDPATH**/ ?>