


<?php $__env->startSection('navbar-content'); ?>

<div class="flex items-center justify-center h-screen w-full">
        <div class="bg-white p-8 rounded-lg shadow-lg max-w-screen-xl w-full mx-4">
            <h1 class="text-2xl font-semibold mb-4">Modification de l'équipe</h1>

            <form action="<?php echo e(route('equipe.update', $equipe->id)); ?>" method="POST" class="mb-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-4">
                    <label class="block font-semibold mb-1">Nom de l'équipe</label>
                    <input type="text" name="nom" value="<?php echo e($equipe->nom); ?>" class="w-full border rounded px-3 py-2">
                </div>

                <!-- Ajoutez d'autres champs de formulaire ici si nécessaire -->

                <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition">Mettre à jour</button>
            </form>

            <h2 class="text-xl font-semibold mb-4">Membres de l'équipe</h2>
            <div class="overflow-x-auto">
                <table class="w-full table-auto">
                    <thead>
                        <tr>
                            <th class="px-4 py-2">Nom</th>
                            <th class="px-4 py-2">Prénom</th>
                            <th class="px-4 py-2">Téléphone</th>
                            <th class="px-4 py-2">Rôle</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $equipe->utilisateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collaborateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="border px-4 py-2"><?php echo e($collaborateur->nom); ?></td>
                                <td class="border px-4 py-2"><?php echo e($collaborateur->prenom); ?></td>
                                <td class="border px-4 py-2"><?php echo e($collaborateur->telephone); ?></td>
                                <td class="border px-4 py-2"><?php echo e($collaborateur->role); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\Dent\resources\views/equipe/modifier.blade.php ENDPATH**/ ?>