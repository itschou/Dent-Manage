<?php $__env->startSection('navbar-content'); ?>


<div class="bg-gradient-to-r from-teal-500 to-blue-500 text-white p-12 rounded-lg shadow-lg">
    <h1 class="text-4xl font-bold mb-4">Bienvenue dans DentAssist</h1>
    <div class="text-lg">
        <p class="mb-2"><span class="font-semibold">Nom:</span> <?php echo e(Auth::user()->nom); ?></p>
        <p class="mb-2"><span class="font-semibold">Prénom:</span> <?php echo e(Auth::user()->prenom); ?></p>
        <p class="mb-2"><span class="font-semibold">Rôle:</span> <?php echo e(Auth::user()->role); ?></p>
    </div>
</div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\DentAssist-Management\resources\views/home.blade.php ENDPATH**/ ?>