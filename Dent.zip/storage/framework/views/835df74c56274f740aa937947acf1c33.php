


<?php $__env->startSection('navbar-content'); ?>



<div class="max-w-lg mx-auto p-4">
    <h1 class="text-2xl font-semibold mb-4">Modifier mon profile</h1>
    <form action="<?php echo e(route('user.setProfile', $user->id)); ?>" method="POST" class="space-y-4">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div>
            <label for="nom" class="block font-medium">Nom complet:</label>
            <input type="text" id="nom" value="<?php echo e(Auth::user()->nom); ?> <?php echo e(Auth::user()->prenom); ?>" name="nom" class="w-full border rounded p-2" disabled>
        </div>
        <div>
            <label for="prenom" class="block font-medium">Equipe :</label>
            <input type="text" id="prenom" value="<?php echo e($equipe); ?>" name="prenom" class="w-full border rounded p-2" disabled>
        </div>
        <div>
            <label for="telephone" class="block font-medium">Téléphone :</label>
            <input type="text" id="telephone" value="<?php echo e(Auth::user()->telephone); ?>" name="telephone" class="w-full border rounded p-2">
        </div>
        <div>
            <label for="email" class="block font-medium">Email :</label>
            <input type="email" id="email" value="<?php echo e(Auth::user()->email); ?>" name="email" class="w-full border rounded p-2" disabled>
        </div>
        <div>
            <label for="password" class="block font-medium">Mot de passe :</label>
            <input type="password" id="password" value="<?php echo e(Auth::user()->password); ?>" name="password" class="w-full border rounded p-2" placeholder="Nouveau mot de passe">
        </div>

        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Modifier mon profile</button>
        
    </form>

    <br>

    
<div class="overflow-x-auto w-full">
        <table class="w-full table-auto border border-gray-300">
            <thead>
                <tr class="bg-gray-100">
                    <th class="border p-2">Prénom</th>
                    <th class="border p-2">Rôle</th>
                    <th class="border p-2">Numéro de téléphone</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $collaboorateurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collaboorateur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-100">
                    <td class="border p-2"><?php echo e($collaboorateur->prenom); ?></td>
                    <td class="border p-2"><?php echo e($collaboorateur->role); ?></td>
                    <td class="border p-2"><?php echo e($collaboorateur->telephone); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    


</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\DentAssist-Management\resources\views/users/profile.blade.php ENDPATH**/ ?>