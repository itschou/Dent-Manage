<?php

namespace App\Http\Controllers;

use App\Models\Hebergement;
use Illuminate\Http\Request;

class HebergementController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function __construct()
    {
        $this->middleware(['auth', 'statusCheck']);
    }


    public function index(Hebergement $hebergement)
    {

        $hebergementget = $hebergement->first();
        return view('hebergement.index', compact('hebergementget'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Hebergement $hebergement)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Hebergement $hebergement)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Hebergement $hebergement)
    {
        $hebergement->update($request->all());

        notify()->success("Les prix d'hébergement ont bien été mis à jour !", 'Bravo !');


        return to_route('hebergement.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Hebergement $hebergement)
    {
        //
    }
}
